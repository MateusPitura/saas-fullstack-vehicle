<?php

namespace WPForms\Vendor\Rs\Json\Pointer;

class InvalidPointerException extends \Exception
{
}
