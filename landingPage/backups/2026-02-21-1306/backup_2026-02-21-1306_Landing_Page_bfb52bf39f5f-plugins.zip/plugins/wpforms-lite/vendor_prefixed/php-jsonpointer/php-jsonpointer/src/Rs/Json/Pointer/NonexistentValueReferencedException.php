<?php

namespace WPForms\Vendor\Rs\Json\Pointer;

class NonexistentValueReferencedException extends \Exception
{
}
