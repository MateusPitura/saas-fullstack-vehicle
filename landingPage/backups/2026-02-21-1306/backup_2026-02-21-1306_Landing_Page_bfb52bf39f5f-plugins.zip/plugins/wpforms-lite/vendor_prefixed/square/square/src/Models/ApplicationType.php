<?php

declare (strict_types=1);
namespace WPForms\Vendor\Square\Models;

class ApplicationType
{
    public const TERMINAL_API = 'TERMINAL_API';
}
